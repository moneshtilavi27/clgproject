<script type="text/javascript">
        
        $(document).ready(function() {
    $('#example').DataTable( {
        "pagingType": "full_numbers"
    } );
} );
    </script>

 <!-- footer -->
<div id="sticky-footer" class="container-fluid">
           <div class="wthree-copyright m-3">
            <p class="text-center" style="font-weight:600"> © 2020 </a></p>
           </div>
   </div>

  <!-- / footer -->
</div>
<!--main content end-->

</body>
</html>